package model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@Table(name = "service")
public class Service {
    
}
